
const database = 'NEW_DATABASE_NAME';
const collection = 'NEW_COLLECTION_NAME';


use(database);


db.createCollection(collection);

